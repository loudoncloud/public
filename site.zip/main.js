
var myImage = document.querySelector('img');
myImage.onclick = function () {
    var mySource = myImage.getAttribute('src');
    if (mySource === 'firefox1.png') {
        myImage.setAttribute('src', 'firefox2.jpg');
    } else {
        myImage.setAttribute('src', 'firefox1.png');
    }
}

var mySpan = document.querySelector('span');
mySpan.ondblclick = function () {
    mySpan.setAttribute('background-color', '#ffffff');
}

var myBtn = document.querySelector('button');
var myHdg = document.querySelector('h1');

myBtn.onclick = function () {
    setUserName();
}

function setUserName () {
    var myName = prompt('Please enter your name');
    localStorage.setItem('name', myName);
    myHdg.textContent = 'Mozilla is cool, ' + myName;
}

if(!localStorage.getItem('name')) {
    setUserName();
  } else {
    var storedName = localStorage.getItem('name');
    myHdg.textContent = 'Mozilla is cool, ' + storedName;
  }
